package hello

const Welcome = "My first Go program!"

func HelloWorld() string {
	return "Hello, World!"
}
