package main

import (
	"fmt"
	"github.com/fatih/color"
)

func main() {
	fmt.Println("hello")
	color.Blue("I'm blue daba dee daba di!")

}
